package com.mindtree.module3Two;

import java.io.IOException;
import java.util.Iterator;

import java.io.IOException;
import java.util.Iterator;



import java.io.IOException;
import java.util.*;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;

/**
 * Created by S780094 on 14/05/2017.
 */
public class MathCalculator {

    public static class Map extends MapReduceBase implements Mapper<LongWritable, Text, Text, DoubleWritable> {

        public void map(LongWritable key, Text value, OutputCollector<Text, DoubleWritable> output, Reporter reporter) throws IOException {
            String line = value.toString();
            String elements[] = line.split("\t");
            output.collect(new Text(elements[0]),new DoubleWritable(Double.parseDouble(elements[2])));

        }
    }
    public static class Reduce extends MapReduceBase implements Reducer<Text, DoubleWritable, Text, Text> {


        public void reduce(Text key, Iterator<DoubleWritable> values, OutputCollector<Text, Text> output, Reporter reporter) throws IOException {

            double sum = 0.0;
            int count = 0;
            double max =0.0;
            double min= Double.MAX_VALUE;
            StringBuilder result = new StringBuilder();
            while(values.hasNext()){
                double temp = values.next().get();
                if(temp<min){
                    min = temp;
                }
                if(temp>max)
                {
                    max=temp;
                }
                sum += temp;
                count++;
            }


            result.append("Min:").append(String.valueOf(min))
                    .append("Max:").append(String.valueOf(max)).
                    append("Sum:").append(String.valueOf(sum)).append("Count:").append(String.valueOf(count));
            output.collect(key, new Text(result.toString()));

        }

        }

    public static void main(String[] args) throws Exception {
        JobConf conf = new JobConf(MathCalculator.class);
        conf.setJobName("Math Calculator");
        conf.setOutputKeyClass(Text.class);
        conf.setOutputValueClass(DoubleWritable.class);
        conf.setMapperClass(Map.class);
        //conf.setCombinerClass(Reduce.class);
        conf.setReducerClass(Reduce.class);
        conf.setNumReduceTasks(1);
        conf.setInputFormat(TextInputFormat.class);
        conf.setOutputFormat(TextOutputFormat.class);
        FileInputFormat.setInputPaths(conf, new Path(args[0]));
        FileOutputFormat.setOutputPath(conf, new Path(args[1]));
        JobClient.runJob(conf);
    }
}
