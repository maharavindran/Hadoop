package com.mindtree.module3one;

import java.io.IOException;
import java.util.Iterator;
import java.io.IOException;
import java.util.*;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;
/**
 * Created by S780094 on 13/05/2017.
 */
public class RemoveGreater20 {
    public static class Map extends MapReduceBase implements Mapper<LongWritable, Text, NullWritable, Text> {

        private final static NullWritable nuWrite = NullWritable.get();

        public void map(LongWritable key, Text value, OutputCollector<NullWritable, Text> output, Reporter reporter) throws IOException {
            String line = value.toString();
            String elements[] = line.split("\t");
            if(Double.parseDouble(elements[2]) > 20.00){
                output.collect(nuWrite,new Text(line));
            }
        }
    }

    public static void main(String[] args) throws Exception {
        JobConf conf = new JobConf(RemoveGreater20.class);
        conf.setJobName("Remove Greater 20");
        conf.setOutputKeyClass(NullWritable.class);
        conf.setOutputValueClass(Text.class);
        conf.setMapperClass(Map.class);
        //conf.setCombinerClass(Reduce.class);
        //conf.setReducerClass(Reduce.class);
        //conf.setNumReduceTasks(1);
        conf.setInputFormat(TextInputFormat.class);
        conf.setOutputFormat(TextOutputFormat.class);
        FileInputFormat.setInputPaths(conf, new Path(args[0]));
        FileOutputFormat.setOutputPath(conf, new Path(args[1]));
        JobClient.runJob(conf);
    }
}