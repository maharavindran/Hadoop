package UDF;

/**
 * Created by S780094 on 13/05/2017.
 */
import java.io.IOException;
import java.util.Iterator;

import com.sun.org.apache.xpath.internal.operations.Bool;
import org.apache.hadoop.util.StringUtils;
import org.apache.pig.EvalFunc;
import org.apache.pig.PigWarning;
import org.apache.pig.data.Tuple;
import org.apache.pig.piggybank.evaluation.IsNumeric;


public class NumericCheck extends IsNumeric {
    //CONCAT multiple fields Java UDF
    @Override
    public Boolean exec(Tuple input) throws IOException {

        if (input == null || input.size() == 0){
            return false;
        }

        int numOfInputs = input.size();

        StringBuilder concatValue = new StringBuilder("");

        String value0 = input.get(0).toString();
        String value1 = input.get(1).toString();

        System.out.println(value0);


        return value0 != null && value0.matches("[-+]?\\d*\\.?\\d+") && value1 != null && value1.matches("[-+]?\\d*\\.?\\d+");



    }
}
