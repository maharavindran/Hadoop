package UDF;

/**
 * Created by S780094 on 13/05/2017.
 */
import java.io.IOException;
import java.util.Iterator;


import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;



public class PigUDF extends EvalFunc<String>{
    //CONCAT multiple fields Java UDF

    @Override
    public String exec(Tuple input) throws IOException {
        if (input == null || input.size() == 0){
            return "";
        }

        int numOfInputs = input.size();

        StringBuilder concatValue = new StringBuilder("");

        Object value0 = (Object) input.get(0);
        Object value3 =(Object) input.get(3);
            if((value0 != null) || value3!=null){
                concatValue.append(value0);
                concatValue.append(value3);
            }

        return concatValue.toString();
    }
}
