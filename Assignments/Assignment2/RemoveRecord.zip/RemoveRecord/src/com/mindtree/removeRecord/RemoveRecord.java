package com.mindtree.removeRecord;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;

import java.io.IOException;
import java.util.Iterator;

public class RemoveRecord {

        public static class Map extends MapReduceBase implements Mapper<LongWritable, Text, NullWritable,Text> {
            private Text word = new Text();
            public void map(LongWritable longWritable, Text text, OutputCollector<NullWritable, Text> output, Reporter reporter) throws IOException {
                word = text;
                String lengthString = word.toString();
                if(lengthString.length()>15){
                    output.collect( NullWritable.get(),new Text(lengthString));
                }

            }
        }

        public static void main(String[] args) throws Exception {
            JobConf conf = new JobConf(RemoveRecord.class);
            conf.setJobName("Remove record");
            conf.setOutputKeyClass(NullWritable.class);
            conf.setOutputValueClass(Text.class);
            conf.setMapperClass(Map.class);
            //conf.setCombinerClass(Reduce.class);
            //conf.setReducerClass(Reduce.class);
            conf.setInputFormat(TextInputFormat.class);
            conf.setOutputFormat(TextOutputFormat.class);
            FileInputFormat.setInputPaths(conf, new Path(args[0]));
            FileOutputFormat.setOutputPath(conf, new Path(args[1]));
            JobClient.runJob(conf);
        }
    }