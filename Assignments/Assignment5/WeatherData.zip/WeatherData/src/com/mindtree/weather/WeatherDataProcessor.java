package com.mindtree.weather;

import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapred.*;

/**
 * Created by S780094 on 14/05/2017.
 */
public class WeatherDataProcessor {

    public static class MaxTemperatureMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {

        public void map(LongWritable key, Text value, OutputCollector<Text, Text> output, Reporter reporter) throws IOException {

            //Converting the record (single line) to String and storing it in a String variable line

            String line = value.toString();

            //Checking if the line is not empty

            if (!(line.length() == 0)) {

                //date

                String date = line.substring(6, 14);

                //maximum temperature

                float temp_Max = Float
                        .parseFloat(line.substring(39, 45).trim());

                //minimum temperature

                float temp_Min = Float
                        .parseFloat(line.substring(47, 53).trim());

                //if maximum temperature is greater than 35 , its a hot day

                if (temp_Max > 42.0) {
                    // Hot day
                    output.collect(new Text(date),
                            new Text("Hot Day"));
                }

                //if minimum temperature is less than 10 , its a cold day

                if (temp_Min < 8) {
                    // Cold day
                    output.collect(new Text(date),
                            new Text("Cold Day"));
                }
            }
        }

    }

//Reducer

    /**
     *MaxTemperatureReducer class is static and extends Reducer abstract class
     having four hadoop generics type Text, Text, Text, Text.
     */

    public static class MaxTemperatureReducer extends MapReduceBase implements Reducer<Text, Text, Text, Text> {


        public void reduce(Text key, Iterator<Text> values, OutputCollector<Text, Text> output, Reporter reporter) throws IOException {


            //putting all the values in temperature variable of type String

            String temperature = values.next().toString();
            output.collect(key, new Text(temperature));
        }

    }




    public static void main(String[] args) throws Exception {


        JobConf conf = new JobConf(WeatherDataProcessor.class);
        conf.setJobName("Weather Data Processor");
        conf.setOutputKeyClass(Text.class);
        conf.setOutputValueClass(Text.class);
        conf.setMapperClass(MaxTemperatureMapper.class);
        //conf.setCombinerClass(Reduce.class);
        conf.setReducerClass(MaxTemperatureReducer.class);
        conf.setNumReduceTasks(1);
        conf.setInputFormat(TextInputFormat.class);
        conf.setOutputFormat(TextOutputFormat.class);
        org.apache.hadoop.mapred.FileInputFormat.setInputPaths(conf, new Path(args[0]));
        org.apache.hadoop.mapred.FileOutputFormat.setOutputPath(conf, new Path(args[1]));
        JobClient.runJob(conf);
    }
}
