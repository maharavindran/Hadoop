package com.mindtree.mapsidejoin;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

public class Main {

    public static class MyMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {

        private Map<String, String> abMap = new HashMap<String, String>();
        private Text outputKey = new Text();
        private Text outputValue = new Text();

        protected void setup(JobContext context) throws java.io.IOException, InterruptedException {
            URI[] files = context.getCacheFiles();
            ;


            for (URI p : files) {
                if (p.getPath().equals("store_locations.txt")) {
                    BufferedReader reader = new BufferedReader(new FileReader(p.toString()));
                    String line = reader.readLine();
                    while (line != null) {
                        String[] tokens = line.split("\t");
                        String ab = tokens[0];
                        String state = tokens[1];
                        abMap.put(ab, state);
                        line = reader.readLine();
                    }
                }
            }
            if (abMap.isEmpty()) {
                throw new IOException("Unable to load Abbrevation data.");
            }
        }


        public void map(LongWritable key, Text value, OutputCollector<Text, Text> output, Reporter reporter) throws IOException {
            {


                String row = value.toString();
                String[] tokens = row.split("\t");
                String inab = tokens[0];
                String state = abMap.get(inab);
                outputKey.set(state);
                outputValue.set(row);
                output.collect(outputKey, outputValue);
            }
        }


        public static void main(String[] args)
                throws IOException, ClassNotFoundException, InterruptedException {

            JobConf job = new JobConf(Main.class);
            job.setJobName("MapSideJoin");
            job.setNumReduceTasks(0);
            job.addResource(new Path("/store_locations.txt"));
            job.setMapperClass(MyMapper.class);
            job.setMapOutputKeyClass(Text.class);
            job.setMapOutputValueClass(Text.class);
            FileInputFormat.setInputPaths(job, new Path(args[0]));
            FileOutputFormat.setOutputPath(job, new Path(args[1]));

            JobClient.runJob(job);
        }
    }
}
