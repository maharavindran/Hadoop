package com.mindtree.multiinput;


import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;


import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.lib.MultipleInputs;



public class MultiInput{

    public static void main(String[] args) throws Exception{


        JobConf job = new JobConf();
        job.setJobName("Multiple inputs");
        job.setJarByClass(MultiInput.class);
        MultipleInputs.addInputPath(job, new Path(args[0]), TextInputFormat.class, MultipleMap1.class);
        MultipleInputs.addInputPath(job,new Path(args[1]), TextInputFormat.class, MultipleMap2.class);
        //job.setReducerClass(MultipleReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        FileOutputFormat.setOutputPath(job, new Path(args[2]));
        JobClient.runJob(job);
    }

}
