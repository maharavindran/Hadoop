package com.mindtree.counter;

import java.io.IOException;


import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.mapred.lib.NullOutputFormat;
import org.apache.hadoop.mapreduce.Counter;

public class MyCounter {

    public static enum LTGT{
        LT10,
        GT50

    };

    private final static NullWritable nuWrite = NullWritable.get();

    public static class MyMapper extends MapReduceBase implements org.apache.hadoop.mapred.Mapper<LongWritable, Text, NullWritable, NullWritable> {

        private Text out = new Text();

        public void map(LongWritable key, Text value, OutputCollector<NullWritable, NullWritable> output, Reporter reporter) throws IOException {

            String line = value.toString();
            String[]  strts = line.split("\\s+");
           int val = Integer.parseInt(strts[1].toString().trim());

            if(val<10){
                reporter.getCounter(LTGT.LT10).increment(1);
            }
            if(val>50){
                reporter.getCounter(LTGT.GT50).increment(1);
            }
            out.set("success");
            output.collect(nuWrite,nuWrite);
        }
    }


    public static void main(String[] args)
            throws IOException, ClassNotFoundException, InterruptedException {

        JobConf conf = new JobConf(MyCounter.class);
        conf.setJobName("Math Calculator");
        conf.setOutputKeyClass(NullWritable.class);
        conf.setOutputValueClass(NullWritable.class);
        conf.setMapperClass(MyMapper.class);
        //conf.setCombinerClass(Reduce.class);
        conf.setInputFormat(TextInputFormat.class);
        conf.setOutputFormat(NullOutputFormat.class);
        org.apache.hadoop.mapred.FileInputFormat.setInputPaths(conf, new Path(args[0]));
        //org.apache.hadoop.mapred.FileOutputFormat.setOutputPath(conf, new Path(args[1]);
        Counters counters = JobClient.runJob(conf).getCounters();
        Counter c1 = counters.findCounter(LTGT.GT50);
        System.out.println(c1.getDisplayName()+ " : " + c1.getValue());
        c1 = counters.findCounter(LTGT.LT10);
        System.out.println(c1.getDisplayName()+ " : " + c1.getValue());


    }
}
