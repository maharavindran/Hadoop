package com.mindtree.partitioner;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.mapred.Partitioner;



import java.io.IOException;
import java.util.Iterator;

public class CustomPartitioner{


    public static class PartitionMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {

        @Override
        public void map(LongWritable key, Text value,
                        OutputCollector<Text, Text> output, Reporter reporter)
                throws IOException {

            String[] tokens = value.toString().split("\\s+");
            System.out.println(tokens[0]);
            System.out.println(tokens[1]);
            System.out.println(tokens[2]);
            System.out.println(tokens[3]);
            tokens[0] = tokens[0].toString().trim();
            String gender = tokens[2].toString().trim();
            tokens[1] = tokens[1].toString().trim();
            tokens[3] = tokens[3].toString().trim();
            String nameAgeScore = tokens[0]+"\t"+tokens[1]+"\t"+tokens[3];

            output.collect(new Text(gender), new Text(nameAgeScore));
        }
    }


    public static class AgePartitioner implements Partitioner<Text, Text> {

        @Override
        public int getPartition(Text key, Text value,int numPartitions) {

            String [] nameAgeScore = value.toString().split("\t");
            String age = nameAgeScore[1];
            int ageInt = Integer.parseInt(age);

            //if the age is <20, assign partition 0
            if(ageInt <=20){
                return 0;
            }
            //else if the age is between 20 and 50, assign partition 1
            if(ageInt >20 && ageInt <=50){

                return 1 ;
            }
            //otherwise assign partition 2
            else
                return 2 ;

        }

        @Override
        public void configure(JobConf arg0) {
            // Gives you a new instance of JobConf if you want to change Job
            // Configurations
        }
    }



    public static class ParitionReducer extends MapReduceBase implements Reducer<Text, Text, Text, Text> {


        @Override
        public void reduce(Text key, Iterator<Text> values,
                           OutputCollector<Text, Text> output, Reporter reporter)
                throws IOException {

            int maxScore = Integer.MIN_VALUE;

            String name = " ";
            String age = " ";
            String gender = " ";
            int score = 0;
            //iterating through the values corresponding to a particular key
            while(values.hasNext()){

                String [] valTokens = values.next().toString().split("\\t");
                score = Integer.parseInt(valTokens[2]);

                if(score > maxScore){
                    name = valTokens[0];
                    age = valTokens[1];
                    gender = key.toString();
                    maxScore = score;
                }
            }
            output.collect(new Text(name), new Text("age- "+age+"\t"+gender+"\tscore-"+maxScore));
        }
    }
    public static void main(String[] args) throws Exception {

        JobConf conf = new JobConf();
        conf.setJobName("Partitioner");

        // Forcing program to run 3 reducers
        conf.setNumReduceTasks(3);

        conf.setMapperClass(PartitionMapper.class);
        conf.setReducerClass(ParitionReducer.class);
        conf.setPartitionerClass(AgePartitioner.class);

        conf.setOutputKeyClass(Text.class);
        conf.setOutputValueClass(Text.class);

        conf.setInputFormat(TextInputFormat.class);
        conf.setOutputFormat(TextOutputFormat.class);

        FileInputFormat.setInputPaths(conf, new Path(args[0]));
        FileOutputFormat.setOutputPath(conf, new Path(args[1]));

        JobClient.runJob(conf);
    }




}